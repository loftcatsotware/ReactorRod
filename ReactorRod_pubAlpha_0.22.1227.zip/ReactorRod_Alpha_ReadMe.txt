Reactor Rod ***** PUBLIC ALPHA *****
Release version 0.22.1227

https://loftcat.itch.io/reactor-rod

This is a playable alpha demo of the first 3 levels of Reactor Rod. 
Game, graphics and sound are in development, watch the itch page for more updates!

Latest updates:
* intro sequence made
* Bug fix with enemy hedgehogs and rocks
* Score added for opening walls
* Player die graphics
* Enemy patterns completed for levels 1 to 3
* Amended timing of intro movement
* Improved aim sequence for drowned or killed
* Sounds amended (more to be added)

Installing
==========
Unzip this folder to a location on your PC.
Run the ReactorRod.exe file to play.
To create a desktop shortcut, right click on your desktop, choose New and choose Shortcut. Browse to the ReactorRod.exe file and select.

